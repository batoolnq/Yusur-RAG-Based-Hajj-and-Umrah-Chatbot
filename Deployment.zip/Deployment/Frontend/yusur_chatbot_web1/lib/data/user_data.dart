// lib/data/user_data.dart
// lib/data/user_data.dart
class UserData {
  static List<Map<String, String>> registeredUsers = [];
}
